<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.

# FRONTEND IMPLEMENTATION GUIDE
## Actors: 
Citizen (reports/voting), Admin (resolution)
## Key Features: 
F1-F5 as specified in ../SRS.md
## BUSINESS LOGIC: 
Follow ../SRS.md exactly for Citizen/Admin permissions

## USER CONTEXT
- Wallet address → SQLite drafts → Contract role lookup
- Active status requires stake >= x (contract check)

## ROUTE PERMISSIONS
app/register: F1 onboarding (Citizen only)
app/report: F2 drafts + F3 submit (Citizen)
app/voting: F4 public queue + vote (Citizen Active)
app/admin: F5 approve/reject (Admin only)


## CODE PATTERNS
**Role Check Hook:**
```tsx
const useUserRole = () => {
  const { address } = useAccount();
  const { data: role } = useReadContract({ 
    address: PUBLIC_SERVICE,
    abi: publicServiceAbi,
    functionName: 'userRoles',
    args: [address!],
  });
  return role; // 0=Citizen, 1=Admin
};
```

**Draft CRUD API**: app/api/drafts/route.ts (better-sqlite3)
**IPFS Upload**: app/api/upload/route.ts (Pinata JWT)

<!-- END:nextjs-agent-rules -->
