'use client';

import { Box, Heading, Text, Link, VStack } from '@chakra-ui/react';

export default function Home() {
  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      minHeight="100vh"
      bg="gray.50"
      p={8}
    >
      <VStack spacing={4} textAlign="center">
        <Heading as="h1" size="2xl">
          Welcome to the Public Service Reporting dApp
        </Heading>
        <Text fontSize="lg" color="gray.600">
          Report incidents, vote on submissions, and help improve your community.
        </Text>
        <Link href="/report" color="teal.500" fontSize="xl" fontWeight="bold">
          Start by creating a report
        </Link>
      </VStack>
    </Box>
  );
}
